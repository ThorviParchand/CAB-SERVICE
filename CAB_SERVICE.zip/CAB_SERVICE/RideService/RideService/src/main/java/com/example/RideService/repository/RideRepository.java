package com.example.RideService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.RideService.entity.Ride;

@Repository
public interface RideRepository extends JpaRepository<Ride, Long> {
	
}

