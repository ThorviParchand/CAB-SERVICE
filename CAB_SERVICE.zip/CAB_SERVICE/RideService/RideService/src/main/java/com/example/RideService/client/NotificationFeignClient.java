package com.example.RideService.client;

import javax.management.Notification;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service")
public interface NotificationFeignClient {
    @PostMapping("/notification")
    void sendNotification(@RequestBody Notification notification);
}

