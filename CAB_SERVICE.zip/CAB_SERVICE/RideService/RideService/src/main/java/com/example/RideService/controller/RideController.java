package com.example.RideService.controller;

import java.util.List;

import javax.management.Notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Location;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.PaymentService.entity.Payment;
import com.example.RideService.client.LocationFeignClient;
import com.example.RideService.client.NotificationFeignClient;
import com.example.RideService.client.PaymentFeignClient;
import com.example.RideService.entity.Ride;
import com.example.RideService.repository.RideRepository;

@RestController
@RequestMapping("/ride")
public class RideController {

    @Autowired
    private RideRepository rideRepository;

    @Autowired
    private PaymentFeignClient paymentFeignClient;

    @Autowired
    private LocationFeignClient locationFeignClient;

    @Autowired
    private NotificationFeignClient notificationFeignClient;

    // Get Ride by ID
    @GetMapping("/{id}")
    public ResponseEntity<Ride> getRide(@PathVariable Long id) {
        return rideRepository.findById(id)
                .map(ride -> ResponseEntity.ok().body(ride))
                .orElse(ResponseEntity.notFound().build());
    }

    // Add Ride
    @PostMapping("/add")
    public ResponseEntity<Ride> createRide(@RequestBody Ride ride) {
        Ride savedRide = rideRepository.save(ride);
        return ResponseEntity.ok(savedRide);
    }

    // Get All Rides
    @GetMapping("/all")
    public List<Ride> getAllRides() {
        return rideRepository.findAll();
    }

    // Get Payment Details for a Ride
    @GetMapping("/{rideId}/payment/{paymentId}")
    public ResponseEntity<Payment> getRidePayment(@PathVariable Long rideId, @PathVariable Long paymentId) {
        if (!rideRepository.existsById(rideId)) {
            return ResponseEntity.notFound().build();
        }
        Payment payment = paymentFeignClient.getPaymentById(paymentId);
        return ResponseEntity.ok(payment);
    }

    // Get Location Details for a Ride
    @GetMapping("/{rideId}/location/{locationId}")
    public ResponseEntity<Location> getRideLocation(@PathVariable Long rideId, @PathVariable Long locationId) {
        if (!rideRepository.existsById(rideId)) {
            return ResponseEntity.notFound().build();
        }
        Location location = locationFeignClient.getLocationById(locationId);
        return ResponseEntity.ok(location);
    }

    // Send Notification for a Ride
    @PostMapping("/{rideId}/notify")
    public ResponseEntity<String> notifyUser(@PathVariable Long rideId, @RequestBody Notification notification) {
        if (!rideRepository.existsById(rideId)) {
            return ResponseEntity.notFound().build();
        }
        notificationFeignClient.sendNotification(notification);
        return ResponseEntity.ok("Notification sent successfully!");
    }
}