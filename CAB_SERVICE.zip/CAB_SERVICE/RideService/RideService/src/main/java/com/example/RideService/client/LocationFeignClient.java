package com.example.RideService.client;

import org.springframework.beans.factory.parsing.Location;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "location-service")
public interface LocationFeignClient {
    @GetMapping("/location/{id}")
    Location getLocationById(@PathVariable("id") Long id);
}
