package com.example.LocationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
