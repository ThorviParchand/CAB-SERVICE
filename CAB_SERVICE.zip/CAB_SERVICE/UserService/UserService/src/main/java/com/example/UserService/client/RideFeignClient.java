package com.example.UserService.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.RideService.entity.Ride;

@FeignClient(name = "ride-service")
public interface RideFeignClient {
    @GetMapping("/ride/{id}")
    Ride getRideById(@PathVariable("id") Long id);
}

