package com.example.UserService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.RideService.entity.Ride;
import com.example.UserService.client.RideFeignClient;
import com.example.UserService.entity.User;
import com.example.UserService.repository.UserRepository;

@RestController
@RequestMapping("/user")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RideFeignClient rideFeignClient;

    // Get a single user by ID
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(user -> ResponseEntity.ok().body(user))
                .orElse(ResponseEntity.notFound().build());
    }

    // Add a new user
    @PostMapping("/add")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User savedUser = userRepository.save(user);
        return ResponseEntity.ok(savedUser);
    }

    // Get all users
    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userRepository.findAll();
        return ResponseEntity.ok(users);
    }

    // Get ride details for a specific user using Feign Client
    @GetMapping("/{userId}/ride/{rideId}")
    public ResponseEntity<Ride> getUserRide(@PathVariable Long userId, @PathVariable Long rideId) {
        // Optionally check if the user exists
        if (!userRepository.existsById(userId)) {
            return ResponseEntity.notFound().build();
        }
        
        // Fetch ride details from Ride Service using Feign Client
        Ride ride = rideFeignClient.getRideById(rideId);
        return ResponseEntity.ok(ride);
    }
}